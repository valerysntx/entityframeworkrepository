namespace entityframeworkrepository.core.entity
{
    public interface IEntity
    {
    }
}
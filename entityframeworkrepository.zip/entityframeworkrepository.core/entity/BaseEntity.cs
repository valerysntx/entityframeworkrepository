﻿namespace entityframeworkrepository.core.entity
{

    public abstract class BaseEntity
    {

    }
}
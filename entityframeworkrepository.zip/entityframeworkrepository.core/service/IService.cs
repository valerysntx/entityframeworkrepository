namespace entityframeworkrepository.core.service
{
    public interface IService
    {
    }
}